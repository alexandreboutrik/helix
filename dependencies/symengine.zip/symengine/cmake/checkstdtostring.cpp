#include <string>
#include <iostream>
int main() {
   std::cout << std::to_string(0) << std::endl;
}
